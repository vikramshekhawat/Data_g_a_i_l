package com.gail.service;

public interface EmailService {

	public void sendEmail(String toAddress, String fromAddress, String subject, String msgBody);

}
