package com.gail.dao;

import com.gail.model.GkarmSkill;

public interface GkarmSkillDao extends GenericDao<GkarmSkill, Long>{

}
