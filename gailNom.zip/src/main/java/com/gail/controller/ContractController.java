package com.gail.controller;

import java.math.BigInteger;

import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gail.model.Contracts;
import com.gail.responseData.ContractsDataList;
import com.gail.restURIConstants.GailNominationURI;
import com.gail.service.ContractsService;
import com.gail.utility.GailNominationServiceException;
import com.gail.utility.ResponseBuilder;

@RestController
@RequestMapping(value = "/", produces = MediaType.APPLICATION_JSON_VALUE)
public class ContractController {

	public static final Logger logger = LoggerFactory.getLogger(ContractController.class);

	@Autowired
	ServletContext context;

	@Autowired
	ContractsService contractsService;

	@PostMapping(value = GailNominationURI.BUILD_CONTRACT_REPORT, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getContracts(
			@RequestBody @Validated(Contracts.DownloadContracts.class) Contracts contractData)
			throws MethodArgumentNotValidException {
		ResponseEntity<Object> response = null;
		logger.info("downloading contracts");
		try {
			Contracts contracts = contractsService.downloadContractReport(contractData.getContractEndDate());
			response = ResponseBuilder.getSuccessResponse(contracts);
			return response;
		} catch (GailNominationServiceException e) {
			response = ResponseBuilder.getErrorResponse(e.getErrorDetails());
			return response;
		}
	}
	
	
	@GetMapping(value=GailNominationURI.GET_CONTRACT_BY_PAYER_ID, consumes=MediaType.ALL_VALUE)
	public ResponseEntity<Object> getContractsByPayerId(@PathVariable("payerId") String payerId, @PathVariable("contractType") String contractType){
		ResponseEntity<Object> response = null;
		ContractsDataList contractsList = null;
		try{
			contractsList = contractsService.getContractDetail(BigInteger.valueOf(Long.parseLong(payerId)), contractType);
			response = ResponseBuilder.getSuccessResponse(contractsList);
		} catch(GailNominationServiceException ex){
			response = ResponseBuilder.getErrorResponse(ex.getErrorDetails());
		}
		return response;
	}
	
	

}
