package com.gail.dao;

import java.util.List;

import com.gail.model.UserContacts;

public interface UserContactsDao {

	public List<UserContacts> getContactsByUserId(Integer userId);

}
