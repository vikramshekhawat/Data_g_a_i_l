package com.gail.daoImpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gail.dao.GkarmBlockDao;
import com.gail.model.GkarmBlock;
import com.gail.utility.QueryConstants;

@Repository("gkarmBlockDao")
public class GkarmBlockDaoImpl extends GenericDaoImpl<GkarmBlock, Long> implements GkarmBlockDao {

	@SuppressWarnings("unchecked")
	@Transactional
	public List<GkarmBlock> findByAuthorAndRecepientId(Long authId, Long receiptId) {
		Query query = currentSession().createQuery(QueryConstants.fetchBlockedUserByAuthRecpt)
				.setParameter("authId", authId).setParameter("receiptId", receiptId);
		if (!query.list().isEmpty()) {
			List<GkarmBlock> blockList = query.list();
			return blockList;
		} else
			return new ArrayList<GkarmBlock>();
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<GkarmBlock> findByAuthorId(Long authId) {
		Query query = currentSession().createQuery(QueryConstants.fetchBlockedListByAuthorId).setParameter("authId",
				authId);
		if (!query.list().isEmpty()) {
			List<GkarmBlock> blockList = query.list();
			return blockList;
		} else
			return new ArrayList<GkarmBlock>();
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<GkarmBlock> findByRecepientId(Long receiptId) {
		Query query = currentSession().createQuery(QueryConstants.fetchBlockedListByRecipientId)
				.setParameter("receiptId", receiptId);
		if (!query.list().isEmpty()) {
			List<GkarmBlock> blockList = query.list();
			return blockList;
		} else
			return new ArrayList<GkarmBlock>();
	}

}
