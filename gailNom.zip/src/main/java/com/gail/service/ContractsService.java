package com.gail.service;

import java.math.BigInteger;

import com.gail.model.Contracts;
import com.gail.responseData.ContractsDataList;
import com.gail.utility.GailNominationServiceException;

public interface ContractsService extends GenericService<Contracts, Long> {

	public Contracts downloadContractReport(String contractEndDate) throws GailNominationServiceException;

	public ContractsDataList getContractDetail(BigInteger payerId, String contractType) throws GailNominationServiceException;

}
