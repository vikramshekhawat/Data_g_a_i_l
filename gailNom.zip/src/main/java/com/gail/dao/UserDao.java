package com.gail.dao;

import java.util.List;
import java.math.BigInteger;

import com.gail.model.User;
import com.gail.responseData.DownloadUserDTO;

public interface UserDao extends GenericDao<User, Long> {

	public User fetchUserByUserName(String userName);

	public String getQuery();

	public List<DownloadUserDTO> getUserReport(String query);
	
		public User getPayerByUserId(BigInteger userId);

}
