package com.gail.dao;

import java.util.List;

import com.gail.model.Ticker;

public interface TickerDao {

	public List<Ticker> getTickersByKey(String payerKey);

}
