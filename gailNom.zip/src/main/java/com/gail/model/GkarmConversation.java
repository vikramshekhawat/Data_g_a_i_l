package com.gail.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "gkarm_conversation")
public class GkarmConversation implements Serializable{
private static final long serialVersionUID = 6740352252098531985L;
    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
    private int conversation;
	private boolean deleted;
	private int listener_id;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getConversation() {
		return conversation;
	}

	public void setConversation(int conversation) {
		this.conversation = conversation;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public int getListener_id() {
		return listener_id;
	}

	public void setListener_id(int listener_id) {
		this.listener_id = listener_id;
	}

}
