package com.gail.daoImpl;

import org.springframework.stereotype.Repository;

import com.gail.dao.GkarmSkillDao;
import com.gail.model.GkarmSkill;

@Repository("gkarmSkillDao")
public class GkarmSkillDaoImpl extends GenericDaoImpl<GkarmSkill, Long> implements GkarmSkillDao{
	
}
