package com.gail.dao;

import com.gail.model.Vendor;

public interface VendorDao extends GenericDao<Vendor, Long> {

	public Boolean isVendor(Integer userId);

}
