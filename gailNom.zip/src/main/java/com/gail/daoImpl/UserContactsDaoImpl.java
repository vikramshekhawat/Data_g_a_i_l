package com.gail.daoImpl;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gail.dao.UserContactsDao;
import com.gail.model.UserContacts;
import com.gail.utility.QueryConstants;

@Repository("userContactsDao")
public class UserContactsDaoImpl extends GenericDaoImpl<UserContacts, Serializable> implements UserContactsDao {
	private static final Logger LOGGER = LoggerFactory.getLogger(UserContactsDao.class);

	@Transactional
	@Override
	public List<UserContacts> getContactsByUserId(Integer userId) {
		Query query = currentSession().createQuery(QueryConstants.getContacts).setParameter("userId", userId);
		if (query.list().size() > 0) {
			return (List<UserContacts>) query.list();

		} else {
			return null;
		}
	}

}
