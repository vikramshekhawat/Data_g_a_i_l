package com.gail.service;

import com.gail.model.User;
import com.gail.utility.GailNominationServiceException;

public interface UserService extends GenericService<User, Long> {

	public User login(User login) throws GailNominationServiceException;

	public User isVendor(Integer userId) throws GailNominationServiceException;

	public User downloadUserReport() throws GailNominationServiceException;

}
