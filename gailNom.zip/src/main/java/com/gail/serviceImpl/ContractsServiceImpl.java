package com.gail.serviceImpl;

import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gail.dao.ContractsDao;
import com.gail.model.Contracts;
import com.gail.responseData.ContractDataDTO;
import com.gail.responseData.ContractsData;
import com.gail.responseData.ContractsDataList;
import com.gail.responseData.DownloadContractsDTO;
import com.gail.service.ContractsService;
import com.gail.utility.Constants;
import com.gail.utility.ErrorDetails;
import com.gail.utility.ExceptionUtil;
import com.gail.utility.GailNominationServiceException;
import com.gail.utility.UTCDate;

import jersey.repackaged.com.google.common.collect.Lists;

@Service("contractsService")
public class ContractsServiceImpl extends GenericServiceImpl<Contracts, Long> implements ContractsService {

	@Autowired
	ContractsDao contractsDao;

	private static final Logger logger = LoggerFactory.getLogger(ContractsServiceImpl.class);

	@SuppressWarnings("rawtypes")
	@Override
	public Contracts downloadContractReport(String contractEndDate) throws GailNominationServiceException {
		logger.info("inside downloadContractReport method of ContractsServiceImpl");
		String filePath = null;
		String query = contractsDao.getQuery(contractEndDate);
		List<List> listsOfResponse = Lists.newArrayList();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
		List<DownloadContractsDTO> downloadContractsDTO;
		Contracts contracts = null;
		try {
			downloadContractsDTO = contractsDao.getContractsDownloadData(query);
			contracts = new Contracts();
			if (downloadContractsDTO != null && !downloadContractsDTO.isEmpty()) {
				for (DownloadContractsDTO downloadContractsDTOs : downloadContractsDTO) {
					List<String> responseList = Lists.newArrayList();
					responseList.add(downloadContractsDTOs.getContract_reference());
					responseList.add(downloadContractsDTOs.getMaterial_code());
					responseList.add(dateFormat.format(downloadContractsDTOs.getStart_date()));
					responseList.add(dateFormat.format(downloadContractsDTOs.getEnd_date()));
					responseList.add(downloadContractsDTOs.getUom());
					responseList.add(downloadContractsDTOs.getPayer_key());
					responseList.add(downloadContractsDTOs.getCustomer_code());
					responseList.add(downloadContractsDTOs.getCustomer_description());
					responseList.add(dateFormat.format(downloadContractsDTOs.getCreated_date()));
					responseList.add(dateFormat.format(downloadContractsDTOs.getUpdated_date()));
					listsOfResponse.add(responseList);
				}
			} else {
				throw new GailNominationServiceException(new ErrorDetails(Constants.DOWNLOAD_CONTRACTS_DATA_NOT_FOUND,
						Constants.ERROR_TYPE_CODE_VALIDATION, Constants.ERROR_TYPE_VALIDATION,
						"No Contracts detail  found for downloading"));
			}

			filePath = generateCSVFile(listsOfResponse);
			contracts.setFileName(filePath);
		} catch (Throwable ex) {
			ExceptionUtil.handleException(
					new ErrorDetails(Constants.DOWNLOAD_CONTRACTS_ERROR, Constants.ERROR_TYPE_CODE_INTERNAL,
							Constants.ERROR_TYPE_ERROR, "Error while downloading contracts."),
					ex, "");
		}
		return contracts;
	}

	@SuppressWarnings("rawtypes")
	private String generateCSVFile(List<List> responseDataList) throws IOException {

		String fileName = String.valueOf(UTCDate.getCurrentUTCDate().getTime());
		String outputFilePath = Constants.FILE_PATH + fileName + Constants.FILE_EXT;
		int rowCount = 0;
		// boolean alreadyExists = new File(outputFile).exists();
		try (FileOutputStream outputStream = new FileOutputStream(outputFilePath, false);) {
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet("report");
			Row row = sheet.createRow(0);

			(row.createCell(0)).setCellValue("CONTRACT REFERENCE");
			(row.createCell(1)).setCellValue("MATERIAL CODE");
			(row.createCell(2)).setCellValue("START DATE");
			(row.createCell(3)).setCellValue("END DATE");
			(row.createCell(4)).setCellValue("UOM");
			(row.createCell(5)).setCellValue("PAYER ID");
			(row.createCell(6)).setCellValue("CUSTOMER CODE");
			(row.createCell(7)).setCellValue("CUSTOMER DESCRIPTION");
			(row.createCell(8)).setCellValue("CREATED DATE");
			(row.createCell(9)).setCellValue("UPDATED DATE");

			for (List nominationResponseDatas : responseDataList) {
				row = sheet.createRow(++rowCount);

				for (int i = 0; i < nominationResponseDatas.size(); i++) {
					Cell cell = row.createCell(i);
					cell.setCellValue((String) nominationResponseDatas.get(i));
				}

			}
			workbook.write(outputStream);

		} catch (IOException e) {
			e.printStackTrace();

		}
		return fileName;
	}

	@Override
	public ContractsDataList getContractDetail(BigInteger payerId, String contractType)
			throws GailNominationServiceException {
		ContractsDataList  contractsList = new ContractsDataList();
		List<ContractsData> list = Lists.newArrayList();
		try{
		String query = contractsDao.getContractsDetailforDisplay(payerId, contractType);
		List<ContractDataDTO> contractsModel = contractsDao.getContractsListForDisplay(query);
		for(ContractDataDTO model : contractsModel) {
				ContractsData contractsData = new ContractsData();
				contractsData.setContractId(model.getContract_id());
				contractsData.setContractRef(model.getContract_ref());
				contractsData.setContractType(model.getContract_type());
				list.add(contractsData); 
			}
			contractsList.setContractsDataList(list);
		}
		 catch(Throwable ex){
		
			ExceptionUtil.handleException(new ErrorDetails(Constants.GETTING_CONTRACT_ERROR, Constants.ERROR_TYPE_CODE_INTERNAL,
					Constants.ERROR_TYPE_ERROR, "Error while getting contract."),
					ex, contractsList.toString());
		
	}
		return contractsList;
	}
}