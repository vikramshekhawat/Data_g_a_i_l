package com.gail.dao;

import com.gail.model.Payer;

public interface PayerDao {
	public Payer fetchUserByPayerId(Integer payerId);

}
