package com.gail.validation.model;

public class ResponseData {
	
	private Object object;
	
	public ResponseData() {
	}

	public ResponseData(Object object) {
		super();
		this.object = object;
	}

	public Object getObject() {
		return object;
	}

	public void setObject(Object object) {
		this.object = object;
	}

}
