package com.gail.utility;

import java.util.List;

import com.gail.validation.model.ContactDataModel;

public class ContactDataList {
	
	private List<ContactDataModel> contactDataList ;

	public List<ContactDataModel> getContactDataList() {
		return contactDataList;
	}

	public void setContactDataList(List<ContactDataModel> contactDataList) {
		this.contactDataList = contactDataList;
	}

	@Override
	public String toString() {
		return "ContactDataList [contactDataList=" + contactDataList + "]";
	}
	


}
