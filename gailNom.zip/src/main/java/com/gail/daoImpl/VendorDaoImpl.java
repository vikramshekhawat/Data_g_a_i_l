package com.gail.daoImpl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gail.dao.VendorDao;
import com.gail.model.Vendor;

@Repository("vendorDao")
public class VendorDaoImpl extends GenericDaoImpl<Vendor, Long> implements VendorDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(VendorDaoImpl.class);

	@SuppressWarnings("rawtypes")
	@Transactional
	public Boolean isVendor(Integer userId) {
		Criteria cr = currentSession().createCriteria(Vendor.class);
		cr.add(Restrictions.eq("userId", userId));
		List list = cr.list();
		if (list.isEmpty() || list.size() < 1) {
			LOGGER.info("No Data found for payerKey {}  ", userId);
			return false;
		} else
			return true;
	}

}
