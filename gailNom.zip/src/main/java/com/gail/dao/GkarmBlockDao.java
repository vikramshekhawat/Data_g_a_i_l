package com.gail.dao;

import java.util.List;

import com.gail.model.GkarmBlock;

public interface GkarmBlockDao extends GenericDao<GkarmBlock, Long> {

	List<GkarmBlock> findByAuthorAndRecepientId(Long authId, Long receiptId);

	List<GkarmBlock> findByAuthorId(Long authId);

	List<GkarmBlock> findByRecepientId(Long receiptId);

}
