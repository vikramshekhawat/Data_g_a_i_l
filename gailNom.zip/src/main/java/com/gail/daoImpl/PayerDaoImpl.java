package com.gail.daoImpl;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gail.dao.PayerDao;
import com.gail.model.Payer;
import com.gail.utility.QueryConstants;
import com.gail.validation.model.LoginRequest;

@Repository("payerDao")
public class PayerDaoImpl extends GenericDaoImpl<LoginRequest, Long> implements PayerDao {

	@Transactional
	public Payer fetchUserByPayerId(Integer payerId) {
		Query query = currentSession().createQuery(QueryConstants.payerExists).setParameter("payerId", payerId);
		if (query.list().size() > 0) {
			return (Payer) query.list().get(0);

		} else {
			return null;
		}
	}

}
