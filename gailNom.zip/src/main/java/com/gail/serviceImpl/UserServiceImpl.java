package com.gail.serviceImpl;

import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gail.dao.PayerDao;
import com.gail.dao.TickerDao;
import com.gail.dao.UserAuthTokenDao;
import com.gail.dao.UserContactsDao;
import com.gail.dao.UserDao;
import com.gail.dao.VendorDao;
import com.gail.model.Payer;
import com.gail.model.Ticker;
import com.gail.model.User;
import com.gail.responseData.DownloadUserDTO;
import com.gail.service.UserService;
import com.gail.utility.Constants;
import com.gail.utility.ErrorDetails;
import com.gail.utility.ExceptionUtil;
import com.gail.utility.GailNominationServiceException;
import com.gail.utility.UTCDate;
import com.gail.utility.Util;

import jersey.repackaged.com.google.common.collect.Lists;

@Service("userService")
public class UserServiceImpl extends GenericServiceImpl<User, Long> implements UserService {

	@Autowired
	UserDao userDao;

	@Autowired
	PayerDao payerDao;

	@Autowired
	VendorDao vendorDao;

	@Autowired
	UserContactsDao userContactsDao;

	@Autowired
	TickerDao tickerDao;

	@Autowired
	UserAuthTokenDao userAuthTokenDao;

	private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

	@Override
	public User login(User login) throws GailNominationServiceException {

		User user = null;
		logger.info("Started login");
		try {
			user = userDao.fetchUserByUserName(login.getUserName());
			if (user != null) {
				Payer payer = payerDao.fetchUserByPayerId(user.getPayerId());
				List<Ticker> tickerList = tickerDao.getTickersByKey(user.getUserName());
				// UserTokenMapping token = new UserTokenMapping();
				if (login.getPassword().length() < 50 || Util.checkPassword(login.getPassword(), user.getPassword())) {

					if (user.getPassword().equals(login.getPassword())
							|| Util.checkPassword(login.getPassword(), user.getPassword())) { // This
																								// line
																								// has
																								// to
																								// be
																								// removed
																								// once
																								// all
																								// the
																								// passwords
																								// are
																								// encrypted
						if (payer == null) {
							throw new GailNominationServiceException(new ErrorDetails(Constants.PAYER_DETAIL_NOT_FOUND,
									Constants.ERROR_TYPE_CODE_VALIDATION, Constants.ERROR_TYPE_VALIDATION,
									"Payer detail not found for corrosponding userId"));
						}

						// token.setToken(Util.tokenGenerator(Constants.TOKEN_GENERATOR_VALUE));
						// token.setUserId(user.getUserId());
						// userAuthTokenDao.saveOrUpdate(token);
						if (user.getPassword().equals(login.getPassword())) {
							user.setPassword(Util.encryptPassword(user.getPassword()));
							userDao.update(user);
						}

						user.setPayerName(payer.getPayerName());
						user.setCutOffTime(payer.getCutOffTime());
						user.setPasswordChanged(user.isPasswordChanged());
						user.setUserId(user.getUserId());
						user.setStatus(user.getStatus());
						// user.setVendorStatus();
						user.setContactList(userContactsDao.getContactsByUserId(user.getUserId()));
						user.setPayerId(user.getPayerId());
						String tickerText = "";
						if (tickerList != null && !tickerList.isEmpty()) {
							for (Ticker ticker : tickerList)
								tickerText = tickerText + ticker.getTickerText() + ", ";
							user.setTickerText(tickerText.substring(0, tickerText.lastIndexOf(",")));
						}
					} else { // This else block has to be removed once all the
								// passwords are encrypted
						if (user.getPassword().equals(login.getPassword())) {
							user.setPassword(Util.encryptPassword(user.getPassword()));
							userDao.update(user);
						}

						throw new GailNominationServiceException(
								new ErrorDetails(Constants.USER_DOES_NOT_EXIST, Constants.ERROR_TYPE_CODE_VALIDATION,
										Constants.ERROR_TYPE_VALIDATION, "Invalid username or password."));
					}
				} else {
					throw new GailNominationServiceException(
							new ErrorDetails(Constants.USER_DOES_NOT_EXIST, Constants.ERROR_TYPE_CODE_VALIDATION,
									Constants.ERROR_TYPE_VALIDATION, "Invalid username or password."));
				}
			} else {
				throw new GailNominationServiceException(
						new ErrorDetails(Constants.USER_DOES_NOT_EXIST, Constants.ERROR_TYPE_CODE_VALIDATION,
								Constants.ERROR_TYPE_VALIDATION, "Invalid username or password."));
			}

		} catch (Throwable ex) {
			ExceptionUtil.handleException(new ErrorDetails(Constants.USER_LOGGING_ERROR,
					Constants.ERROR_TYPE_CODE_INTERNAL, Constants.ERROR_TYPE_ERROR, "Error while logging user."), ex,
					login.toString());
		}

		return user;
	}

	@Override
	public User isVendor(Integer userId) throws GailNominationServiceException {

		User user = new User();
		Boolean vendorStatus = false;
		logger.info("Started login");
		try {
			vendorStatus = vendorDao.isVendor(userId);
			user.setDeviceToken(null);
			user.setUserId(userId);
			user.setVendorStatus(vendorStatus);

		} catch (Throwable ex) {
			ExceptionUtil.handleException(
					new ErrorDetails(Constants.USER_LOGGING_ERROR, Constants.ERROR_TYPE_CODE_INTERNAL,
							Constants.ERROR_TYPE_ERROR, "Exception in getVendorData by materialCode"),
					ex, vendorStatus.toString());
		}

		return user;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public User downloadUserReport() throws GailNominationServiceException {
		String filePath = null;
		String query = userDao.getQuery();
		User user = null;
		List<List> listsOfResponse = Lists.newArrayList();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
		List<DownloadUserDTO> downloadUserDTO;
		try {
			downloadUserDTO = userDao.getUserReport(query);
			if (downloadUserDTO != null && !downloadUserDTO.isEmpty()) {
				user = new User();
				for (DownloadUserDTO downloadUserDTOs : downloadUserDTO) {
					List<String> responseList = Lists.newArrayList();
					responseList.add(downloadUserDTOs.getPayer_id().toString());
					responseList.add(downloadUserDTOs.getPayer_name());
					responseList.add(downloadUserDTOs.getPrimary_email_id());
					responseList.add(downloadUserDTOs.getSecondary_email_id1());
					responseList.add(downloadUserDTOs.getSecondary_email_id2());
					responseList.add(downloadUserDTOs.getSecondary_email_id3());
					responseList.add(downloadUserDTOs.getSecondary_email_id4());
					responseList.add(downloadUserDTOs.getCutoff_time());
					responseList.add(downloadUserDTOs.getRegion());
					responseList.add(dateFormat.format(downloadUserDTOs.getCreated_date()));
					listsOfResponse.add(responseList);

				}
			} else {
				throw new GailNominationServiceException(
						new ErrorDetails(Constants.DOWNLOAD_USER_DATA_NOT_FOUND, Constants.ERROR_TYPE_CODE_VALIDATION,
								Constants.ERROR_TYPE_VALIDATION, "No User detail  found for downloading"));
			}
			filePath = generateCSVFile(listsOfResponse);
			user.setFileName(filePath);
		} catch (Throwable ex) {
			ExceptionUtil.handleException(new ErrorDetails(Constants.DOWNLOAD_USER_ERROR,
					Constants.ERROR_TYPE_CODE_INTERNAL, Constants.ERROR_TYPE_ERROR, "Error while downloading user."),
					ex, "");
		}
		return user;
	}

	@SuppressWarnings("rawtypes")
	private String generateCSVFile(List<List> responseDataList) throws IOException {

		String fileName = String.valueOf(UTCDate.getCurrentUTCDate().getTime());
		String outputFilePath = Constants.FILE_PATH + fileName + Constants.FILE_EXT;
		int rowCount = 0;
		try (FileOutputStream outputStream = new FileOutputStream(outputFilePath, false);) {
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet("report");
			Row row = sheet.createRow(0);
			(row.createCell(0)).setCellValue("PAYER ID");
			(row.createCell(1)).setCellValue("PAYER NAME");
			(row.createCell(2)).setCellValue("PRIMARY EMAIL ID");
			(row.createCell(3)).setCellValue("SECONDARY EMAIL ID 1");
			(row.createCell(4)).setCellValue("SECONDARY EMAIL ID 2");
			(row.createCell(5)).setCellValue("SECONDARY EMAIL ID 3");
			(row.createCell(6)).setCellValue("SECONDARY EMAIL ID 4");
			(row.createCell(7)).setCellValue("CUTOFF TIME");
			(row.createCell(8)).setCellValue("REGION");
			(row.createCell(9)).setCellValue("CREATED DATE");

			for (List nominationResponseDatas : responseDataList) {
				row = sheet.createRow(++rowCount);
				for (int i = 0; i < nominationResponseDatas.size(); i++) {
					Cell cell = row.createCell(i);
					cell.setCellValue((String) nominationResponseDatas.get(i));
				}
			}

			workbook.write(outputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return fileName;
	}

}