package com.gail.dao;

import com.gail.model.UserContacts;

public interface UserContactManagerDao extends GenericDao<UserContacts, Long>{
	

}
