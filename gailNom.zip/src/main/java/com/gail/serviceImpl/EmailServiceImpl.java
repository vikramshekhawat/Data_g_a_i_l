package com.gail.serviceImpl;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;

import com.gail.responseData.EmailData;
import com.gail.service.EmailService;
import com.gail.utility.Constants;
import com.gail.utility.ErrorDetails;
import com.gail.utility.ExceptionUtil;
import com.gail.utility.GailNominationServiceException;

@Service("emailService")
public class EmailServiceImpl implements EmailService {

	public static final Logger logger = LoggerFactory.getLogger(EmailServiceImpl.class);

	@Autowired
	private MailSender mailSenderService; // MailSender interface defines a
											// strategy
											// for sending simple mails

	@Autowired
	private JavaMailSender emailSender;

	public void sendEmail(String toAddress, String fromAddress, String subject, String msgBody) {

		SimpleMailMessage message = new SimpleMailMessage();
		message.setFrom(fromAddress);
		message.setTo(toAddress);
		message.setSubject(subject);
		message.setText(msgBody);
		mailSenderService.send(message);
		try {
			sendTestMail();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void sendTestMail() throws MessagingException {
		MimeMessage message = emailSender.createMimeMessage();
		MimeMessageHelper messageHelper = new MimeMessageHelper(message, true, "UTF-8");
		messageHelper.setFrom("rishabh.sre.92@gmail.com");
		messageHelper.setTo("rishabh.jain@wildnettechnologies.com");
		messageHelper.setSubject("Testing Mime Message");

		// message.addRecipients(Message.RecipientType.TO, addressTo);
		// change accordingly
		// message.setSubject(emailData.getSubject());

		Map<String, String> inputValue = new HashMap<String, String>();
		inputValue.put("TableContentData", "rishabh.jain@wildnettechnologies.com");

		// HTML mail content
		String htmlText = readEmailFromHtml(Constants.EMAIL_TEMPLATE_PATH + "nomination-reminder-template.html",
				inputValue);
		// messageBodyPart.setContent(htmlText, "text/html");

		// multipart.addBodyPart(messageBodyPart);
		// message.setContent(multipart);

		messageHelper.setText("text/html", htmlText);
		emailSender.send(message);

	}

	public void sendProjectNotification(List<EmailData> emailList) throws GailNominationServiceException {
		MimeMessagePreparator[] preparators = new MimeMessagePreparator[10];
		int i = 0;
		try {
			for (final EmailData emailData : emailList) {

				Map<String, String> inputValue = new HashMap<String, String>();
				inputValue.put("TableContentData", emailData.getEmailValues());

				InternetAddress[] addressTo = new InternetAddress[emailData.getEmail().length];
				for (int j = 0; j < emailData.getEmail().length; j++) {
					addressTo[j] = new InternetAddress(emailData.getEmail()[j]);
				}

				String htmlText = readEmailFromHtml(Constants.EMAIL_TEMPLATE_PATH + "nomination-reminder-template.html",
						inputValue);

				preparators[i++] = new MimeMessagePreparator() {
					public void prepare(MimeMessage mimeMessage) throws Exception {
						final MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true, "UTF-8");
						message.setSubject(emailData.getSubject());
						message.setTo(addressTo);
						message.setFrom("");
						message.setText(htmlText, true);
					}
				};
			}
			emailSender.send(preparators);
		} catch (Throwable ex) {
			ExceptionUtil.handleException(new ErrorDetails(Constants.MAIL_ERROR, Constants.ERROR_TYPE_CODE_INTERNAL,
					Constants.ERROR_TYPE_ERROR, "Error while sending reminder mail."), ex, "");
		}
	}

	// public void sendProjectNotification(final Collection<User> users, final
	// Project project) {
	// MimePreparator[] preparators = new MimePreparator[users.size()];
	// int i = 0;
	// for (final User user: users)
	// {
	// preparators[i++] = new MimeMessagePreparator()
	// {
	// public void prepare(MimeMessage mimeMessage) throws Exception
	// {
	// final MimeMessageHelper message = new MimeMessageHelper(mimeMessage,
	// true, "UTF-8");
	// message.setSubject("New project has been posted:#"+project.getId());
	// message.setTo(user.getEmail());
	// message.setFrom(ApplicationProperties.GENERAL_FROM);
	// final Map<String, Object> model = new TreeMap<String, Object>();
	// model.put("user", user);
	// model.put("project", project);
	// final String text =
	// VelocityEngineUtils.mergeTemplateIntoString(velocityEngine,
	// ApplicationProperties.PROJECT_SUBMISSION_NOTIFICATION_VM, model);
	// message.setText(text, true);
	// }
	// };
	// }
	// mailSender.send(preparators);
	// }

	/*
	 * private void sendReminderMail(Map<BigInteger, List<ReminderContractDto>>
	 * unfilledContractsMap, String currentDate) throws
	 * GailNominationServiceException {
	 * 
	 * UserContactManager userContactManager = null; Properties properties =
	 * System.getProperties(); Transport transport = null;
	 * 
	 * 
	 * int count = 0;
	 * 
	 * try { Iterator<Entry<BigInteger, List<ReminderContractDto>>> iterator =
	 * unfilledContractsMap.entrySet() .iterator();
	 * 
	 * for (Map.Entry<BigInteger, List<ReminderContractDto>> entry :
	 * unfilledContractsMap.entrySet()) { if
	 * (Boolean.valueOf(GailNominationResource.properties.getProperty(
	 * "CHECK_MAX_LIMIT_OF_EMAILS")) && count > Integer
	 * .valueOf(GailNominationResource.properties.getProperty(
	 * "MAX_LIMIT_OF_EMAILS"))) {
	 * logger.error("Maximum limit of {} mails reached",
	 * GailNominationResource.properties.getProperty("MAX_LIMIT_OF_EMAILS"));
	 * break; } StringBuffer tableContent = new StringBuffer(); for
	 * (ReminderContractDto contract : entry.getValue()) { // materialModel = //
	 * materialDao.getMaterialByCode(contract.getMaterialCode());
	 * tableContent.append( "<tr>" +
	 * "<td align='center' style='border:1px solid #999;color:#3f3f3f;font-size:12px;margin:0 0 20px 0;padding:0;font-weight:bold; font-family:Arial, Helvetica, sans-serif; line-height:20px'>"
	 * + currentDate + "</td>" +
	 * "<td align='center' style='border:1px solid #999;color:#3f3f3f;font-size:12px;margin:0 0 20px 0;padding:0;font-weight:bold; font-family:Arial, Helvetica, sans-serif; line-height:20px'>"
	 * + contract.getCustomer_code() + "</td>" +
	 * "<td align='center' style='border:1px solid #999;color:#3f3f3f;font-size:12px;margin:0 0 20px 0;padding:0;font-weight:bold; font-family:Arial, Helvetica, sans-serif; line-height:20px'>"
	 * + contract.getContract_ref() + "</td>" +
	 * "<td align='center' style='border:1px solid #999;color:#3f3f3f;font-size:12px;margin:0 0 20px 0;padding:0;font-weight:bold; font-family:Arial, Helvetica, sans-serif; line-height:20px'>"
	 * + contract.getContract_type() + "</td>" +
	 * "<td align='center' style='border:1px solid #999;color:#3f3f3f;font-size:12px;margin:0 0 20px 0;padding:0;font-weight:bold; font-family:Arial, Helvetica, sans-serif; line-height:20px'>"
	 * + contract.getMaterial_code() + "</td>" +
	 * 
	 * "<td align='center' style='border:1px solid #999;color:#3f3f3f;font-size:12px;margin:0 0 20px 0;padding:0;font-weight:bold; font-family:Arial, Helvetica, sans-serif; line-height:20px'>"
	 * +contract.getUOM() +"</td>"+
	 * 
	 * "</tr>"); } List<String> emailList = Lists.newArrayList();
	 * 
	 * // Android & iOS Notification List<String> androidTokenList =
	 * Lists.newArrayList(); List<String> iosTokenList = Lists.newArrayList();
	 * 
	 * userContactManager = new UserContactManager(); List<ContactData>
	 * contactDataList =
	 * userContactManager.getContactListByPayerId(entry.getKey());// Get //
	 * user-contact // data
	 * 
	 * logger.info("EmailIds associated with payerId {} fetched",
	 * entry.getKey());
	 * 
	 * for (ContactData contactData : contactDataList) { String email =
	 * contactData.getContactValue(); emailList.add(email);
	 * 
	 * // Android & iOS Notification if
	 * ("android".equalsIgnoreCase(contactData.getDeviceType()))
	 * androidTokenList.add(contactData.getDeviceToken()); else if
	 * ("ios".equalsIgnoreCase(contactData.getDeviceType()))
	 * iosTokenList.add(contactData.getDeviceToken()); }
	 * 
	 * // Android & iOS Notification // if (!androidTokenList.isEmpty()) //
	 * PushNotificationHelper.sendAndroidNotification(androidTokenList, //
	 * Constants.SUBJECT_NOMINATION_REMINDER,
	 * Constants.SUBJECT_NOMINATION_REMINDER); // if (!iosTokenList.isEmpty())
	 * // PushNotificationHelper.sendIOSNotification(iosTokenList,
	 * Constants.SUBJECT_NOMINATION_REMINDER);
	 * 
	 * String[] emailArr = emailList.toArray(new String[emailList.size()]);
	 * EmailData emailData = new EmailData(); emailData.setEmail(emailArr);
	 * 
	 * emailData.setSubject(Constants.SUBJECT_NOMINATION_REMINDER);
	 * emailData.setType(Constants.NOMINATION_REMINDER);
	 * emailData.setEmailValues(tableContent.toString());
	 * 
	 * Map<String, String> inputValue = new HashMap<String, String>();
	 * inputValue.put("TableContentData", emailData.getEmailValues());
	 * 
	 * // MimeMessage message = new MimeMessage(session); // message.setFrom( //
	 * new InternetAddress(GailNominationResource.properties.getProperty(
	 * "FROM_FOR_EMAIL_SENDING")));
	 * 
	 * InternetAddress[] addressTo = new
	 * InternetAddress[emailData.getEmail().length]; for (int i = 0; i <
	 * emailData.getEmail().length; i++) { addressTo[i] = new
	 * InternetAddress(emailData.getEmail()[i]); }
	 * 
	 * MimeMessage message = emailSender.createMimeMessage(); MimeMessageHelper
	 * messageHelper = new MimeMessageHelper(message, true, "UTF-8");
	 * messageHelper.setFrom("rishabh.sre.92@gmail.com");
	 * messageHelper.setTo(addressTo);
	 * messageHelper.setSubject(emailData.getSubject());
	 * 
	 * // message.addRecipients(Message.RecipientType.TO, addressTo); // change
	 * accordingly // message.setSubject(emailData.getSubject());
	 * 
	 * MimeMultipart multipart = new MimeMultipart(); BodyPart messageBodyPart =
	 * new MimeBodyPart();
	 * 
	 * // HTML mail content String htmlText =
	 * readEmailFromHtml(Constants.EMAIL_TEMPLATE_PATH +
	 * "nomination-reminder-template.html", inputValue); //
	 * messageBodyPart.setContent(htmlText, "text/html");
	 * 
	 * // multipart.addBodyPart(messageBodyPart); //
	 * message.setContent(multipart);
	 * 
	 * messageHelper.setText("Plain message", htmlText);
	 * emailSender.send(message);
	 * 
	 * count++;
	 * 
	 * // send message transport.sendMessage(message, addressTo);
	 * logger.info("Mail sent to PayerId: {}", entry.getKey()); } } catch
	 * (Throwable ex) { ExceptionUtil.handleException( new
	 * ErrorDetails(Constants.MAIL_ERROR, Constants.ERROR_TYPE_CODE_INTERNAL,
	 * Constants.ERROR_TYPE_ERROR, "Error while sending reminder mail."), ex,
	 * unfilledContractsMap.toString()); } try { transport.close();
	 * logger.info("Transport connection successfully closed "); } catch
	 * (MessagingException e) {
	 * logger.error("Error occured while terminating transport connection: " +
	 * e); e.printStackTrace(); } }
	 */

	protected String readEmailFromHtml(String filePath, Map<String, String> input) {
		String msg = readContentFromFile(filePath);
		if (input != null) {
			try {
				Set<Entry<String, String>> entries = input.entrySet();
				for (Map.Entry<String, String> entry : entries) {
					msg = msg.replace(entry.getKey().trim(), entry.getValue().trim());
				}
			} catch (Exception exception) {
				logger.error("Error occured with readEmailFromHtml " + exception.getStackTrace());
			}
		}
		return msg;
	}

	private String readContentFromFile(String fileName) {
		StringBuffer contents = new StringBuffer();

		try {
			// use buffering, reading one line at a time
			BufferedReader reader = new BufferedReader(new FileReader(fileName));
			try {
				String line = null;
				while ((line = reader.readLine()) != null) {
					contents.append(line);
					contents.append(System.getProperty("line.separator"));
				}
			} finally {
				reader.close();
			}
		} catch (IOException ex) {
			logger.error("Error occured with readContentFromFile " + ex.getStackTrace());
		}
		return contents.toString();
	}

}
